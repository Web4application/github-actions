#include <stdio.h>
#include "ascii.h"

// Function to print an ASCII art
void print_ascii_art() {
    printf("ASCII Art Example:\n");
    printf("  ___   ___ \n");
    printf(" / _ \\ / _ \\\n");
    printf("| | | | | | |\n");
    printf("| |_| | |_| |\n");
    printf(" \\___/ \\___/\n");
}
