#ifndef ASCII_H
#define ASCII_H

// Function declaration
void print_ascii_art();

#endif // ASCII_H
