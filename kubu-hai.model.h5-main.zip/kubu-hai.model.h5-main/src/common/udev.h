#ifndef UDEV_H
#define UDEV_H

// Function declarations
int initialize_udev();
void finalize_udev();

#endif // UDEV_H
