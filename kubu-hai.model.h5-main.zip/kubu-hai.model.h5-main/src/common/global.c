#include "global.h"

// Global variable example
int global_variable = 42;

// Function to get the value of the global variable
int get_global_variable() {
    return global_variable;
}

// Function to set the value of the global variable
void set_global_variable(int value) {
    global_variable = value;
}
