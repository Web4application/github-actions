from hume import HumeClient

client = HumeClient(
    api_key="h5RJsbByxogjY8C6jQLYyjabJF13ysthzioYl3cHEaZeGRD1",
)
client.empathic_voice.custom_voices.list_custom_voices()
