docker build -t my-python-image .
